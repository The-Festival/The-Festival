<?php

class JazzRepository{
    public function getAllArtists(){
        return;
    }   
}