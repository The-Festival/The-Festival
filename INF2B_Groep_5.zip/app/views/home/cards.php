<div class="row justify-content-center">
<div class="col-4"><a><button class="buttonNav">Jazz</button></a></div>
<div class="col-4"><a href="yummy/yummy"><button class="buttonNav">Yummy</button></a></div>
</div>
<div class="row justify-content-center">
<div class="col-4"><a><button class="buttonNav">History</button></a></div>
<div class="col-4"><a><button class="buttonNav">Kids</button></a></div>
</div>