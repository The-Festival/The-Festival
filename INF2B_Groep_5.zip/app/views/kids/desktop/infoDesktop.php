<?php
include __DIR__ . '/../../header.php';
?>
<link href='https://fonts.googleapis.com/css?family=Nunito' rel='stylesheet'>
<style>
<?php include 'infoDesktopStyle.css'; ?>
</style>
<body>
    

<div class="container">
	<div class="row">
		<div class="col">
        <br><br><br>
        <h1>Kids Scavenger Hunt</h1>  
        <p>Special for our kids we have designed a scavenger hunt to make this festival also entertaining for the kids. The scavenger hunt consist of 2 different activities, one of these is the exciting and immersive Egg Problem with the magnificent Dr. Feathers. In this activity our kids need to solve the egg problem to help Dr Feathers with his journey.
         Next up we have Prof. Digit our kids have the mission to find the lost calculator of Prof. Digit, to do this they have a couple of challenges that they need to face and some question that they need to answer.</p>
            <br><br><br>
        <h1>Check The Hunt</h1>
        <p>For the special scavenger hunt that we made for the kids the only thing you need to do is to enter this website on your mobile. For more information about the other activities  you check the other pages on the your desktop or laptop.</p>
        </div>
        <div id = "divImage" class="col d-flex align-items-center">
            <img class="mx-auto img-fluid" src="/img/mobileDesign.png" alt="mobile design">
        </div>
	</div>
    <div class = "col">
            <button id = "buttonApp"><a href="/kids/app">Go to mobile app!</a></button>
        </div>
</div>
    
</body>