<link href='https://fonts.googleapis.com/css?family=Itim' rel='stylesheet'>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.3.1/dist/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
<style>
<?php include 'theeggproblemStyle.css'; ?>
</style>
<body>
<header>
<div class="">
    <div class="">
        <img id="logo" class="" src="/../img/logo.png" alt="mobile design">
    </div>
</div>
</header>
<div class = "container">
    <div class = "row mt-5">
        <div class = "col "><img src="/../img/fireworks.png" alt=""></div>
        <div class = "col"><img src="/../img/Dr.Feathers.png" alt=""></div>
        <div class = "col"><img src="/../img/fireworks.png" alt=""></div>
    </div>
    <h1>Well done, you found Dr. Feathers! Let's keep going and solve the mystery.</h1>
    <button class = "button" onclick="window.location.href='/kids/eggproblemfacts'">Continue</button>
</div>
</body>