<link href='https://fonts.googleapis.com/css?family=Itim' rel='stylesheet'>
<style>
<?php include 'activityStyle.css'; ?>
</style>
<body>
<div class="container">
  <div class = "col">
      <div>
        <img src="/../img/notebook.png" alt="">
      </div>
      <div class = "textDiv">
        <h1>Tyler’s Secret</h1>
      </div>
      <div class = "textDiv">
        <h1>Search the museum for a secret code that will show you where Dr. Tyler's notebook is hidden. Good luck on your mission!</h1>
      </div>
      <div>
        <button id = "buttonBack"><a href="/kids/app">BACK</a></button>
      </div>
  </div>
</div>
</body>


