<link href='https://fonts.googleapis.com/css?family=Itim' rel='stylesheet'>
<style>
<?php include 'activityStyle.css'; ?>
</style>
<body>
<div class="container">
  <div class = "col">
      <div>
        <img src="/../img/drfeathersandegg.png" alt="img">
      </div>
      <div class = "textDiv">
        <h1>The Egg Problem</h1>
      </div>
      <div class = "textDiv">
        <h1>Join Dr. Feathers in solving the mystery of the fresh and old egg! Can you help uncover the clues and crack the case?</h1>
      </div>
      <div>
          <button> <a href="/kids/theeggproblem">Solve the mystery</a></button>
      </div>
      <div>
        <button><a href="/kids/app">BACK</a></button>
      </div>
  </div>
</div>
</body>


