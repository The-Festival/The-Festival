<link href='https://fonts.googleapis.com/css?family=Itim' rel='stylesheet'>
<style>
<?php include 'activityStyle.css'; ?>
</style>
<body>
<div class="container">
  <div class = "col">
      <div>
        <img src="/../img/finalenigma.png" alt="">
      </div>
      <div class = "textDiv">
        <h1>The Final Enigma</h1>
      </div>
      <div class = "textDiv">
        <h1>You're almost there! Answer the questions in the Tyler's Museum to solve the final puzzle and crack the enigma. Good luck!</h1>
      </div>
      <div>
        <button id = "buttonBack"><a href="/kids/app">BACK</a></button>
      </div>
  </div>
</div>
</body>


