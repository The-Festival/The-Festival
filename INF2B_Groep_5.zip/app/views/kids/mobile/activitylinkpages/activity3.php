<link href='https://fonts.googleapis.com/css?family=Itim' rel='stylesheet'>
<style>
<?php include 'activityStyle.css'; ?>
</style>
<body>
<div class="container">
  <div class = "col">
      <div>
        <img src="/../img/Prof. Digit.png" alt="">
      </div>
      <div class = "textDiv">
        <h1>The Lost Calculator</h1>
      </div>
      <div class = "textDiv">
        <h1>Help Prof. Digit find the hidden numbers and solve the mystery of The Lost Calculator!</h1>
      </div>
      <div>
      <div onclick="window.location.href = '/kids/lostcalculator'">
          <button>Find numbers</button>
      </div>
        <button id = "buttonBack" onclick="window.location.href = '/kids/app'">BACK</button>
      </div>
  </div>
</div>
</body>


